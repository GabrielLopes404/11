import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  Shield, 
  Zap,
  Users,
  BarChart3,
  Star,
  Sparkles,
  Target,
  Clock,
  LineChart,
  PieChart,
  Wallet
} from "lucide-react";
import { Link } from "wouter";
import logoUrl from "@assets/generated_images/Lucrei_financial_software_logo_280b14ff.png";

const features = [
  {
    icon: Zap,
    title: "Ultra Rápido",
    description: "Desempenho otimizado para máxima produtividade.",
    gradient: "from-yellow-500 to-orange-500"
  },
  {
    icon: Shield,
    title: "100% Seguro",
    description: "Seus dados protegidos com criptografia de ponta.",
    gradient: "from-green-500 to-emerald-500"
  },
  {
    icon: BarChart3,
    title: "Analytics Avançado",
    description: "Insights poderosos em tempo real.",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: Target,
    title: "Precisão Total",
    description: "Controle financeiro milimétrico.",
    gradient: "from-purple-500 to-pink-500"
  },
];

const stats = [
  { icon: Users, value: "10K+", label: "Empresas Ativas" },
  { icon: TrendingUp, value: "98%", label: "Satisfação" },
  { icon: Clock, value: "24/7", label: "Suporte" },
  { icon: DollarSign, value: "R$2B+", label: "Processado" },
];

export default function LandingNew() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b backdrop-blur-xl bg-background/80 supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-6">
          <div className="flex h-20 items-center justify-between">
            <div className="flex items-center gap-3 group cursor-pointer">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-chart-2 rounded-full blur-md opacity-50 group-hover:opacity-75 transition-opacity" />
                <img src={logoUrl} alt="Lucrei" className="relative h-12 w-12 transition-transform group-hover:scale-110 duration-300" />
              </div>
              <span className="text-3xl font-bold bg-gradient-to-r from-primary via-chart-2 to-primary bg-clip-text text-transparent animate-gradient">
                Lucrei
              </span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm font-medium hover:text-primary transition-all duration-300 relative group">
                Recursos
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-chart-2 transition-all group-hover:w-full" />
              </a>
              <a href="#testimonials" className="text-sm font-medium hover:text-primary transition-all duration-300 relative group">
                Depoimentos
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-chart-2 transition-all group-hover:w-full" />
              </a>
              <a href="#pricing" className="text-sm font-medium hover:text-primary transition-all duration-300 relative group">
                Preços
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-chart-2 transition-all group-hover:w-full" />
              </a>
              <Link href="/login" className="text-sm font-medium text-muted-foreground hover:text-primary transition-all duration-300">
                Você trabalha aqui?
              </Link>
              <Link href="/login">
                <Button variant="outline" className="hover-elevate">
                  Entrar
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-gradient-to-r from-primary to-chart-2 hover:shadow-lg hover:shadow-primary/50 transition-all duration-300 hover:scale-105">
                  <Sparkles className="mr-2 h-4 w-4" />
                  Começar Grátis
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-chart-2/5 to-background" />
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]" />
        <div 
          className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-br from-primary/20 to-chart-2/20 rounded-full blur-3xl animate-pulse"
          style={{ transform: `translateY(${scrollY * 0.5}px)` }}
        />
        <div 
          className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-chart-1/20 to-success/20 rounded-full blur-3xl animate-pulse"
          style={{ transform: `translateY(${-scrollY * 0.3}px)` }}
        />

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-in slide-in-from-left duration-1000">
              <Badge className="bg-gradient-to-r from-primary to-chart-2 text-primary-foreground border-0 hover:shadow-lg hover:shadow-primary/50 transition-all duration-300">
                <Sparkles className="mr-1 h-3 w-3" />
                7 Dias Grátis - Sem Cartão
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold leading-tight">
                Gestão Financeira
                <span className="block mt-2 bg-gradient-to-r from-primary via-chart-2 to-chart-1 bg-clip-text text-transparent animate-gradient">
                  Sem Complicação
                </span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                A plataforma mais intuitiva e poderosa para transformar a gestão financeira da sua empresa. 
                <span className="text-primary font-semibold"> Simples, rápido e eficiente.</span>
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/login">
                  <Button 
                    size="lg" 
                    className="text-lg px-8 bg-gradient-to-r from-primary to-chart-2 hover:shadow-2xl hover:shadow-primary/50 transition-all duration-300 hover:scale-105 group"
                  >
                    Iniciar Teste Gratuito
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="text-lg px-8 hover-elevate"
                >
                  Ver Demonstração
                </Button>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  <span className="text-sm text-muted-foreground">Sem cartão de crédito</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  <span className="text-sm text-muted-foreground">Cancele quando quiser</span>
                </div>
              </div>
            </div>

            <div className="relative animate-in slide-in-from-right duration-1000">
              {/* Dashboard Preview */}
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-chart-2 rounded-2xl blur-2xl opacity-20 animate-pulse" />
                <Card className="relative border-2 shadow-2xl overflow-hidden hover-elevate">
                  <CardContent className="p-8 space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Saldo Total</p>
                        <p className="text-4xl font-bold bg-gradient-to-r from-success to-emerald-600 bg-clip-text text-transparent">
                          R$ 187.432,90
                        </p>
                      </div>
                      <div className="p-3 rounded-full bg-gradient-to-br from-success/20 to-emerald-500/20">
                        <TrendingUp className="h-8 w-8 text-success" />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl bg-gradient-to-br from-success/10 to-success/5 border border-success/20">
                        <div className="flex items-center gap-2 mb-2">
                          <Wallet className="h-4 w-4 text-success" />
                          <p className="text-xs text-muted-foreground">Receitas</p>
                        </div>
                        <p className="text-xl font-bold text-success">R$ 98.450,00</p>
                        <p className="text-xs text-success/60 mt-1">+23% vs mês anterior</p>
                      </div>
                      <div className="p-4 rounded-xl bg-gradient-to-br from-destructive/10 to-destructive/5 border border-destructive/20">
                        <div className="flex items-center gap-2 mb-2">
                          <LineChart className="h-4 w-4 text-destructive" />
                          <p className="text-xs text-muted-foreground">Despesas</p>
                        </div>
                        <p className="text-xl font-bold text-destructive">R$ 43.210,00</p>
                        <p className="text-xs text-destructive/60 mt-1">-8% vs mês anterior</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {[
                        { label: "Vendas", value: 85, color: "bg-success" },
                        { label: "Operacional", value: 65, color: "bg-primary" },
                        { label: "Marketing", value: 45, color: "bg-chart-2" },
                      ].map((item, i) => (
                        <div key={i} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{item.label}</span>
                            <span className="font-semibold">{item.value}%</span>
                          </div>
                          <div className="h-2 bg-muted rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${item.color} rounded-full transition-all duration-1000 ease-out`}
                              style={{ width: `${item.value}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-6 -right-6 p-4 bg-background border rounded-xl shadow-xl animate-float">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-success/20 rounded-lg">
                    <PieChart className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Lucro Líquido</p>
                    <p className="font-bold text-success">+R$ 55K</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 border-y bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center space-y-2 animate-in fade-in duration-1000" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="mx-auto w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-chart-2/20 flex items-center justify-center mb-3">
                  <stat.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="text-3xl font-bold bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/30 to-background" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16 space-y-4 animate-in fade-in duration-1000">
            <Badge className="bg-primary/10 text-primary border-primary/20">
              Recursos Poderosos
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold">
              Tudo que você precisa para
              <span className="block mt-2 bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                crescer seu negócio
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Ferramentas profissionais que simplificam sua gestão financeira
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <Card 
                key={i} 
                className="group relative overflow-hidden hover-elevate transition-all duration-500 border-2 hover:border-primary/50 cursor-pointer"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
                <CardContent className="p-6 space-y-4 relative">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} p-0.5 group-hover:scale-110 transition-transform duration-500`}>
                    <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                      <feature.icon className="h-7 w-7 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-chart-2 to-chart-1" />
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
        <div className="container mx-auto px-6 relative z-10 text-center">
          <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-1000">
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Comece a transformar suas finanças hoje
            </h2>
            <p className="text-xl text-white/90">
              Junte-se a milhares de empresas que já revolucionaram sua gestão financeira
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/login">
                <Button 
                  size="lg" 
                  className="text-lg px-8 bg-white text-primary hover:bg-white/90 hover:shadow-2xl transition-all duration-300 hover:scale-105 group"
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  Iniciar Teste Gratuito
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
            <p className="text-sm text-white/70">
              7 dias grátis • Sem cartão de crédito • Cancele quando quiser
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img src={logoUrl} alt="Lucrei" className="h-8 w-8" />
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                Lucrei
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 Lucrei. Transformando gestão financeira.
            </p>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes gradient {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 3s ease infinite;
        }
        
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
