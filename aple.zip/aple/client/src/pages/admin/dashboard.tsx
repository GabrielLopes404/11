import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserCheck, Shield, Clock } from "lucide-react";
import { MetricCard } from "@/components/metric-card";

interface Stats {
  totalUsers: number;
  activeUsers: number;
  admins: number;
  recentLogins: number;
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const response = await fetch("/api/admin/stats");
      if (!response.ok) throw new Error("Erro ao buscar estatísticas");
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="h-4 w-24 bg-muted rounded" />
                <div className="h-4 w-4 bg-muted rounded" />
              </CardHeader>
              <CardContent>
                <div className="h-8 w-16 bg-muted rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Painel Administrativo</h1>
        <p className="text-muted-foreground">
          Gerencie usuários e monitore o sistema
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total de Usuários"
          value={String(stats?.totalUsers || 0)}
          icon={Users}
        />
        <MetricCard
          title="Usuários Ativos"
          value={String(stats?.activeUsers || 0)}
          icon={UserCheck}
        />
        <MetricCard
          title="Administradores"
          value={String(stats?.admins || 0)}
          icon={Shield}
        />
        <MetricCard
          title="Logins Recentes (7 dias)"
          value={String(stats?.recentLogins || 0)}
          icon={Clock}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Visão Geral</CardTitle>
            <CardDescription>
              Estatísticas do sistema de gestão financeira
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Taxa de usuários ativos</span>
                <span className="text-sm font-medium">
                  {stats ? Math.round((stats.activeUsers / stats.totalUsers) * 100) : 0}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Taxa de administradores</span>
                <span className="text-sm font-medium">
                  {stats ? Math.round((stats.admins / stats.totalUsers) * 100) : 0}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Engajamento (7 dias)</span>
                <span className="text-sm font-medium">
                  {stats ? Math.round((stats.recentLogins / stats.totalUsers) * 100) : 0}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
            <CardDescription>
              Acesse as funcionalidades principais
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Use o menu lateral para acessar:
              </p>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Gerenciamento de Usuários</li>
                <li>Configurações do Sistema</li>
                <li>Relatórios Administrativos</li>
                <li>Logs de Atividades</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
