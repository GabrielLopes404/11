# Lucrei - Sistema de Gestão Financeira

## Visão Geral
Lucrei é um sistema completo de gestão financeira desenvolvido com React (frontend) e Express (backend), com funcionalidades para usuários e administradores.

## Estado Atual
- ✅ Sistema funcionando completamente
- ✅ Painel administrativo implementado
- ✅ Sistema de autenticação com sessões
- ✅ Configuração Replit completa
- ✅ Deploy configurado

## Estrutura do Projeto

### Backend (Express + TypeScript)
- **server/index.ts**: Servidor principal
- **server/routes.ts**: Rotas da API (autenticação e admin)
- **server/storage.ts**: Sistema de armazenamento em memória

### Frontend (React + Vite)
- **client/src/App.tsx**: Configuração de rotas
- **client/src/pages/**: Páginas do sistema
  - `login.tsx`: Página de login
  - `landing.tsx`: Landing page pública
  - `admin/dashboard.tsx`: Dashboard administrativo
  - `admin/users.tsx`: Gerenciamento de usuários
  - Páginas de usuário: dashboard, contas, fluxo-caixa, etc.

### Componentes
- **client/src/components/**: Componentes reutilizáveis
  - `app-sidebar.tsx`: Sidebar para usuários
  - `admin-sidebar.tsx`: Sidebar para administradores
  - `ui/`: Componentes UI (shadcn/ui)

## Funcionalidades

### Sistema de Autenticação
- Login com username/password
- Sessões com express-session
- Senhas hashadas com bcryptjs
- Diferenciação de roles (admin/user)

### Painel Administrativo
**Acesso**: Login com credenciais de admin
- **Credenciais padrão**: 
  - Username: `admin`
  - Password: `admin123`

**Funcionalidades**:
- Dashboard com estatísticas
- Gerenciamento completo de usuários (criar, editar, deletar, ativar/desativar)
- Controle de roles (admin/user)
- Visualização de último acesso

### Painel de Usuário
- Dashboard financeiro
- Contas a pagar/receber
- Fluxo de caixa
- Conciliação bancária
- Faturas
- Contatos
- Relatórios

## Rotas da API

### Autenticação
- `POST /api/auth/login` - Login de usuários
- `POST /api/auth/register` - Registro de novos usuários
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Dados do usuário atual

### Admin (requer autenticação de admin)
- `GET /api/admin/users` - Listar todos os usuários
- `POST /api/admin/users` - Criar novo usuário
- `PUT /api/admin/users/:id` - Atualizar usuário
- `DELETE /api/admin/users/:id` - Deletar usuário
- `GET /api/admin/stats` - Estatísticas do sistema

## Tecnologias Principais
- **Frontend**: React 18, Vite, TailwindCSS, Wouter (routing), TanStack Query
- **Backend**: Express, TypeScript, Express Session
- **UI Components**: Radix UI, shadcn/ui
- **Autenticação**: bcryptjs, express-session
- **Validação**: Zod
- **Ambiente**: Node.js 20, Replit

## Configuração Replit

### Variáveis de Ambiente
- `SESSION_SECRET`: Chave secreta para sessões (gerada automaticamente)
- `PORT`: 5000 (padrão)

### Workflow
- Nome: `dev`
- Comando: `npm run dev`
- Porta: 5000
- Output: webview

### Deploy
- Target: autoscale
- Build: `npm run build`
- Run: `npm run start`

## Como Usar

### Desenvolvimento
```bash
npm run dev
```

### Build
```bash
npm run build
```

### Produção
```bash
npm run start
```

## Acesso ao Sistema

### Landing Page
- URL: `/`
- Link "Você trabalha aqui?" → redireciona para `/login`

### Login
- URL: `/login`
- Admin: username `admin`, password `admin123`
- Redireciona admin para `/admin/dashboard`
- Redireciona usuários para `/dashboard`

### Painel Admin
- URLs: `/admin/*`
- Sidebar diferenciada com menu administrativo
- Opção de logout no footer

### Painel Usuário
- URLs: `/dashboard`, `/contas`, `/fluxo-caixa`, etc.
- Sidebar com menu de funcionalidades financeiras

## Modificações Recentes
- ✅ Adicionado sistema de roles (admin/user)
- ✅ Criado painel administrativo completo
- ✅ Implementado gerenciamento de usuários
- ✅ Adicionado link "Você trabalha aqui?" na landing
- ✅ Configurado autenticação com sessões
- ✅ Deploy configurado

## Estrutura de Dados

### User
```typescript
{
  id: string;
  username: string;
  password: string; // hashado
  role: "admin" | "user";
  isActive: boolean;
  createdAt: Date;
  lastLogin: Date | null;
}
```

## Notas Importantes
- O sistema usa armazenamento em memória (MemStorage) - dados são perdidos ao reiniciar
- Usuário admin padrão é criado automaticamente no startup
- As senhas são hashadas com bcrypt (salt rounds: 10)
- Sessões expiram em 7 dias
- Vite configurado para aceitar proxy do Replit (HMR funcional)
